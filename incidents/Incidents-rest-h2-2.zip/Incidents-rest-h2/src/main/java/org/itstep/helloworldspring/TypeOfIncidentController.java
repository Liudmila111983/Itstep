package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

@RestController // С помощью него выполняется обмен данными в формате json

public class TypeOfIncidentController {

    @Autowired
    TypeOfIncidentService typeOfIncidentService; // Присоединяем сервер, который мы перед этим создали

    @GetMapping("/") // "/" подразумевает 8082
    public String index(){
        return "index";
    }

    @GetMapping(value="/type_of_incidents")
    public List<TypeOfIncident> findAll(){
        return typeOfIncidentService.findAll();
    }


    @GetMapping(value="/type_of_incidents/{type_id}")
    public Optional<TypeOfIncident> findById(@PathVariable Long type_id){
        return typeOfIncidentService.findById(type_id);
    }

    @PostMapping(value="/type_of_incidents")
    public TypeOfIncident post(@RequestBody TypeOfIncident type_of_incident){
        return typeOfIncidentService.save(type_of_incident);
    }


    @PutMapping(value="/type_of_incidents/{type_id}")
    public TypeOfIncident update(@RequestBody TypeOfIncident newTypeOfIncident, @PathVariable Long type_id){
        return typeOfIncidentService.findById(type_id).map(type_of_incident->{
            type_of_incident.setDescription(newTypeOfIncident.getDescription());
            return typeOfIncidentService.save(type_of_incident);
        }).orElseGet(()-> typeOfIncidentService.save(newTypeOfIncident));
    }

    @DeleteMapping(value="/type_of_incidents/{type_id}")
            public void delete(@PathVariable Long type_id){
        typeOfIncidentService.deleteById(type_id);
    }






}
