package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class IncidentReportsService {


    @Autowired
    IncidentReportsRepository incidentReportsRepository;

    public List<IncidentReports> findAll(){
        return incidentReportsRepository.findAll();
    }


    public Optional<IncidentReports> findById(Long incident_id){
        return incidentReportsRepository.findById(incident_id);
    }

    public IncidentReports save(IncidentReports incident_reports){return
            incidentReportsRepository.save
                    (incident_reports);}

    public void deleteById(Long incident_id){
        incidentReportsRepository.deleteById(incident_id);
    }

}
