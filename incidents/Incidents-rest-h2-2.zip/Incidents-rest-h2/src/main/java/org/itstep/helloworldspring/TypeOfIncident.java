package org.itstep.helloworldspring;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.Set;

@Data // подставляет геттеры и сеттеры в класс
@AllArgsConstructor
@NoArgsConstructor
@Entity
@Table(name="type_of_incident")

public class TypeOfIncident {
    @Id
    @Column(name = "type_id")
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long type_id;
    private String description;

    @OneToMany(mappedBy="type_id")
    private Set<IncidentReports> incident_reports;

}
