package org.itstep.helloworldspring;

import com.fasterxml.jackson.databind.ObjectMapper;
import org.hamcrest.Matchers;
import org.junit.jupiter.api.*;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.ResultActions;
import org.springframework.test.web.servlet.ResultMatcher;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;

import static org.hamcrest.Matchers.equalTo;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
public class TestApplication {
    @Autowired
    private MockMvc mvc; // Mock объект - это объект специально для тестирования


    @Test
    @Order(1)
    public void index() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(content().string(equalTo("index")));
    }

    @Test // Выводим все типы происшествий
    @Order(2)
    public void types() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/type_of_incidents")
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", Matchers.hasSize(5)))
                .andExpect(jsonPath("$[0].description", Matchers.equalTo("кража")));
    }

    @Test // Вывести один тип происшествия
    @Order(3)
    public void getTypesById() throws Exception {
        mvc.perform(MockMvcRequestBuilders.get("/type_of_incidents/{type_id}",1)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.description", Matchers.equalTo("кража")));
    }


    @ParameterizedTest // Создаем параметризованный тест
    @Order(4)
    @ValueSource(ints = {-1, 0, 1, 2, 3, 4, 5, Integer.MAX_VALUE})
    public void getTypeById(int type_id) throws Exception {
        ResultActions actions = mvc.perform
                (MockMvcRequestBuilders.get("/type_of_incidents/{type_id}",type_id).
                accept(MediaType.APPLICATION_JSON));
        actions
                .andExpect(status().isOk());
        switch (type_id){
            case 1:
                actions
                        .andExpect(jsonPath("$.description", Matchers.equalTo("кража")));
                break;
            case 2:
                actions
                        .andExpect(jsonPath("$.description", Matchers.equalTo("убийство")));
                break;
            case 3:
                actions
                        .andExpect(jsonPath("$.description", Matchers.equalTo("взятка")));
                break;
            case 4:
                actions
                        .andExpect(jsonPath("$.description", Matchers.equalTo("разбой")));
                break;
            case 5:
                actions
                        .andExpect(jsonPath("$.description", Matchers.equalTo("изнасилование")));
                break;
            default:
                actions
                        .andExpect(content().string("null"));
        }
    }

    @Test
    @Order(5)
    public void postTypeOfIncident() throws Exception {
        mvc.perform(MockMvcRequestBuilders.post("/type_of_incidents")
                        .content(asJsonString(new TypeOfIncident(6L,
                                        "распространение клеветыыыыыы", 6L)),
                                new IncidentReports(6L, "2022-02-02", 1L)))
                .contentType(MediaType.APPLICATION_JSON)
                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                //.andExpect((status().isCreated()))
                .andExpect(jsonPath("$.type_id", Matchers.equalTo(6)))
                .andExpect(jsonPath("$.description", Matchers.equalTo("распространение клеветыыыыыы")));
    }

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }


/*
    @Test
    @Order(6)
    @Disabled
    public void putJewelry() throws Exception {
        mvc.perform(
                        MockMvcRequestBuilders.put
                                        ("/jewelries/2")
                                .content(asJsonString(new Jewelry(3L, "name1", "color1", 1.,
                                        2., new Material(1L, "m"))))
                                .contentType(MediaType.APPLICATION_JSON)
                                .accept(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                //.andExpect((status().isCreated()))
                .andExpect(jsonPath("$.name", Matchers.equalTo("name1")))
                .andExpect(jsonPath("$.color", Matchers.equalTo("color1")));
    }


*/
    @Test
    @Order(7)
    @Disabled
    public void deleteType() throws Exception
    {
        mvc.perform( MockMvcRequestBuilders.delete("/type_of_incidents/5") )
                .andExpect(status().isOk());
    }



}
