package org.itstep.helloworldspring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController // С помощью него выполняется обмен данными в формате json

public class IncidentReportsController {

    @Autowired
    IncidentReportsService incidentReportsService; // Присоединяем сервер, который мы перед этим создали

    @GetMapping(value="/incident_reports")
    public List<IncidentReports> findAll(){
        return incidentReportsService.findAll();
    }

        @GetMapping(value="/incident_reports/{incident_id}")
        public Optional<IncidentReports> findById(@PathVariable Long incident_id){
            return incidentReportsService.findById(incident_id);
        }

        @PostMapping(value="/incident_reports")
        IncidentReports createOrSave(@RequestBody IncidentReports incident_reports) {
            return incidentReportsService.save(incident_reports);
        }

        @PutMapping(value="/incident_reports/{incident_id}")
        IncidentReports updateUser(@RequestBody IncidentReports newIncidentReports,
                                   @PathVariable Long incident_id) {
            return incidentReportsService.findById(incident_id).map(incident_reports -> {
                incident_reports.setDate(newIncidentReports.getDate());
                incident_reports.setType_id(newIncidentReports.getType_id());
                return incidentReportsService.save(incident_reports);
            }).orElseGet(() -> incidentReportsService.save(newIncidentReports));

        }

        @DeleteMapping(value="/incident_reports/{incident_id}")
        void deleteById(@PathVariable Long incident_id) {
            incidentReportsService.deleteById(incident_id);
            System.out.println("delete");
        }

}
