insert into type_of_incident(description)
values('кража'), ('убийство'), ('взятка'), ('разбой'), ('изнасилование');

insert into incident_reports(date, type_id)
values('2020-03-29', 1), ('2020-04-03', 2), ('2021-05-25', 1),
('2022-02-15', 4), ('2022-03-27', 3);


