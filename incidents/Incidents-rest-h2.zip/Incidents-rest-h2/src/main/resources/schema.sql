drop table if exists type_of_incident;
drop table if exists incident_reports;
drop table if exists incident_with_type;

CREATE TABLE type_of_incident (
type_id int NOT NULL AUTO_INCREMENT,
description varchar(40) NOT NULL,
PRIMARY KEY (type_id)
);

CREATE TABLE incident_reports (
incident_id int NOT NULL AUTO_INCREMENT,
date TIMESTAMP not null,
type_id int,
foreign key (type_id) references type_of_incident,
PRIMARY KEY (incident_id)
);

create table incident_with_type(
id int NOT NULL AUTO_INCREMENT,
incident_id int,
type_id int
)
